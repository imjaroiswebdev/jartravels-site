import MobileMenu from './modules/MobileMenu';

var mobileMenu = new MobileMenu();